# Codex Sidebar Enhancer

一个面向 macOS Codex 桌面体验的本地侧栏增强工具。它为对话增加摘要、最近消息预览、双列卡片、项目标签搜索、最近使用排序和额度展示，同时不修改应用包或对话正文。

## 一行安装

在“终端”中粘贴并回车：

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/yubowen123/codex-sidebar-enhancer/main/install.sh)"
```

安装器会自动：

1. 下载到 `~/Library/Application Support/Codex Sidebar Enhancer`；
2. 使用系统 Node.js，或 Codex/ChatGPT 桌面应用内置的 Node.js；
3. 安装用户级 LaunchAgent，登录和应用重启后自动恢复；
4. 在 `~/Applications` 创建 **Codex Sidebar Enhancer.app** 启动器；
5. 打开启动器。首次启用时，如 Codex 正在运行，会询问是否重启一次。

以后从 Spotlight、访达的“应用程序”或 `~/Applications` 打开 **Codex Sidebar Enhancer** 即可。它会以本地调试端口启动 Codex/ChatGPT；注入器只连接 `127.0.0.1:9231`。

> 不想直接执行远程脚本？先[查看 install.sh](./install.sh)，或下载仓库后运行 `bash install.sh`。

## 一行卸载

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/yubowen123/codex-sidebar-enhancer/main/uninstall.sh)"
```

卸载会停止增强进程，并移除安装目录、用户级 LaunchAgent、启动器和增强日志，不会删除 Codex 对话或设置。

## 功能

- 每条对话直接展示核心总结。
- 原生悬浮预览增加核心总结、最近输入和最近输出；消息最多展示 3 行。
- 列表/卡片滑块支持鼠标和键盘切换，并记住选择。
- 同一文件夹内一行两张半透明卡片，固定展示名称、最后沟通时间、AI 总结和 3 个核心标签。
- 3 个标签分别提炼任务对象、工作类型和交付结果，过滤版本号、状态码及孤立工具名。
- “置顶 / 项目 / 最近”改为可访问的 Tab，一次只展示一个分组。
- 项目文件夹改为标签：按真实最近沟通时间降序排列，默认两行，可展开全部。
- 搜索框可模糊搜索文件夹名和项目名，命中后直接展示对应文件夹。
- 顶部 6 个功能入口改为图标卡片；超过 6 个时自动换行。
- 顶部展示 Codex 自身记录的真实剩余比例和重置时间，不自行估算额度。
- Windows 常用入口提供 Skill 管理工作台：读取完整安装目录，默认以单列清单呈现常用项；支持创作工作分类、搜索和星标，并保留原生详情与完整列表。
- “新对话”首页集中展示 Taskboard 中正在执行的项目；点击卡片直接进入关联对话。
- 项目执行完成后继续显示为“待查看”，首次点击后收起；钉住的项目跨状态、跨重启持续展示。
- Windows 检测到本机 Asset Console 时，提供与当前 Codex 任务联动的资产工作区：“待处理 / 项目素材 / 精选库”分别表示文件位置，“关联项目”单独决定当前任务的项目目标，今日练习独立保留。“选择项目”里可直接新建资产项目：填写项目名和一个已有的 Windows 文件夹后，会新建并关联当前任务。项目的扫描根、文件夹和子文件夹会补齐为可切换层级，左栏目录项、主区文件夹卡片和顶部路径均可直接点击返回或深入。进入项目文件夹后，一级工具栏直接提供“自动整理”，会整理当前文件夹的全部素材且不受搜索、筛选影响，已经归位的文件不会重复移动；每日练习保留当前日期目录，成片和最终输出区不会参与，完成后可撤销。批量选择后可明确移动到项目、附加到当前对话，或丢弃但不删除文件；任务未关联项目时也可直接选择移动目标。移动窗口也保留一键“自动整理”，会在目标项目的素材区内按项目结构、日期和素材类型归位；多素材区无法可靠判断时先要求选择，不会猜错集数。也可继续手动指定文件夹。工作区切换带有遵循减少动态效果设置的轻量过渡。对比、精选、其他移动和永久删除收在“批量工具”中。移动、标记和删除均可撤销。附加完成后可一键返回对话并聚焦输入框，最多支持 8 项且不会自动发送。独立版 Asset Console 保持不变。

## 系统要求

- macOS 13 或更新版本；
- 已安装 Codex 或包含 Codex 工作区的 ChatGPT 桌面应用；
- 本地存在 `~/.codex` 会话目录；
- Node.js 22 或更新版本。安装器会优先复用系统 Node.js，没有时自动使用桌面应用内置 Node.js。

当前实现已在 Codex `26.803.41515` 对应界面结构上验证。Codex 大版本更新如果更改侧栏 DOM 锚点，可能需要同步升级本项目。

## 隐私与安全

- 只读访问 `~/.codex/session_index.jsonl` 与 `~/.codex/sessions`；
- 不修改 `/Applications/ChatGPT.app`、`/Applications/Codex.app`、`app.asar` 或对话数据；
- 不开启对外 HTTP 服务，不上传对话、额度或标签；
- CDP 只使用回环地址 `127.0.0.1:9231`；
- 安装内容完全位于当前用户目录，可通过卸载脚本完整移除。

## 更新与排查

更新时重新运行安装命令即可。安装器会原子替换旧版本，并迁移早期 `com.yubowen.codex-conversation-preview` LaunchAgent。

日志位置：

```text
~/Library/Logs/CodexSidebarEnhancer/injector.log
~/Library/Logs/CodexSidebarEnhancer/injector.error.log
```

如果增强没有出现：

1. 退出 Codex/ChatGPT；
2. 打开 `~/Applications/Codex Sidebar Enhancer.app`；
3. 等待约 5 秒；
4. 仍未出现时查看上述日志。

## 本地开发

```bash
git clone https://github.com/yubowen123/codex-sidebar-enhancer.git
cd codex-sidebar-enhancer
npm install
npm test
npm run inject
```

实时界面验收脚本需要已用 `9231` 端口启动的 Codex：

```bash
node scripts/verify-shortcut-grid.mjs
node scripts/verify-section-tabs.mjs
node scripts/verify-folder-switcher.mjs
node scripts/verify-card-view.mjs
node scripts/verify-reload-persistence.mjs
node scripts/verify-home-projects.mjs
node scripts/verify-skill-manager.mjs
```

## License

[MIT](./LICENSE)
